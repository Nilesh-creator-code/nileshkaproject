// Background images array (replace with your college images)
const backgroundImages = [
    'https://source.unsplash.com/1600x900/?university',
    'https://source.unsplash.com/1600x900/?college',
    'https://source.unsplash.com/1600x900/?campus',
    'https://source.unsplash.com/1600x900/?library'
];

let currentImageIndex = 0;
const backgroundElement = document.querySelector('.background-slideshow');

// Function to change background image
function changeBackground() {
    const nextImage = new Image();
    nextImage.src = backgroundImages[(currentImageIndex + 1) % backgroundImages.length];
    
    // Preload next image then change
    nextImage.onload = () => {
        currentImageIndex = (currentImageIndex + 1) % backgroundImages.length;
        backgroundElement.style.opacity = '0';
        
        setTimeout(() => {
            backgroundElement.style.backgroundImage = `url(${backgroundImages[currentImageIndex]})`;
            backgroundElement.style.opacity = '1';
        }, 1000);
    };
}

// Initialize first background image
backgroundElement.style.backgroundImage = `url(${backgroundImages[0]})`;

// Change background every 5 minutes
setInterval(changeBackground, 300000);

// Smooth scroll for navigation
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        target.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    });
});

// Update active navigation button based on scroll position
window.addEventListener('scroll', () => {
    const sections = document.querySelectorAll('.section');
    const navButtons = document.querySelectorAll('.nav-btn');
    
    let currentSection = '';
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        if (window.pageYOffset >= sectionTop - 200) {
            currentSection = section.getAttribute('id');
        }
    });
    
    navButtons.forEach(btn => {
        btn.classList.remove('active');
        if (btn.getAttribute('href') === `#${currentSection}`) {
            btn.classList.add('active');
        }
    });
});

// Handle contact form submission
const contactForm = document.getElementById('contactForm');
if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        // Add your form submission logic here
        alert('Thank you for your message! We will get back to you soon.');
        this.reset();
    });
}
